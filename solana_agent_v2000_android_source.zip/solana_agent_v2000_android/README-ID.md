# Solana Agent V2000 — Android

## Apa isi aplikasi ini?
- Aplikasi Android native sederhana yang membuka dashboard lokal.
- Pencarian pasangan/token Solana dari DexScreener.
- Watchlist alamat wallet publik disimpan di perangkat.
- Pemeriksaan tanda tangan transaksi terbaru dari wallet yang dimasukkan melalui Solana mainnet RPC.
- Mode read-only: tidak ada koneksi wallet, penandatanganan transaksi, atau fitur trading.

## Batasan yang perlu diketahui
- Aplikasi hanya memeriksa wallet yang kamu tambahkan, bukan seluruh blockchain Solana.
- Riwayat yang ditampilkan berupa signature/slot transaksi; belum mengurai perpindahan token dan nominal SOL secara lengkap.
- RPC publik dapat membatasi permintaan. Untuk pemantauan stabil/otomatis diperlukan RPC berbayar atau backend.
- Belum ada AI prediktif, Telegram/push alert, smart-money scoring, atau auto-trading.
- Jangan pernah memasukkan seed phrase atau private key.

## Cara mendapatkan APK dari Android
Proyek ini adalah source project Android, bukan APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK, jadi APK tidak bisa dibuat dan diuji langsung di sini.

Cara build melalui GitHub:
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub, lalu unggah seluruh isi folder proyek.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Android APK** lalu tekan **Run workflow** (atau tunggu build setelah push).
5. Setelah selesai, buka hasil workflow dan unduh artifact `solana-agent-v2000-debug-apk`.
6. Ekstrak artifact, lalu instal `app-debug.apk` di Android. Jika diminta, izinkan instalasi dari sumber tersebut.

APK debug cocok untuk uji coba pribadi. Untuk distribusi publik, perlu APK release yang ditandatangani dengan kunci rilis.

## Build lokal
Memerlukan Android Studio/Android SDK, JDK 17, Gradle 8.9:
`gradle assembleDebug`
Hasil: `app/build/outputs/apk/debug/app-debug.apk`
